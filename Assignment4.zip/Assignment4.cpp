// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>


class CustomException : public std::exception
{
    public:
        CustomException(char const* const message) throw()
            : std::exception(message)
        {}

        char const* what() const throw()
        {
            return exception::what();
        }
};

bool do_even_more_custom_application_logic()
{
    throw std::exception("even more custom application logic error");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}
void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    try
    {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (std::exception const& e)
    {
        std::cout << "Error when performing application logic: " << e.what() << std::endl;
    }

    throw CustomException("An error occurred in custom application logic.");

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    if (den == 0)
    {
        throw std::runtime_error("Cannot divide by zero");
    }
    return (num / den);
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0;

    try
    {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (std::runtime_error const& e)
    {
        std::cout << "error while dividing: " << e.what() << std::endl;
    }
}

int main()
{
    try
    {
        std::cout << "Exceptions Tests!" << std::endl;

        do_division();
        do_custom_application_logic();
    }
    catch (CustomException const& e)
    {
        std::cout << "Custom error detected " << e.what();
    }
    catch (std::exception const& e)
    {
        std::cout << "std::exception occurred " << e.what();
    }
    catch (...)
    {
        std::cout << "uncaught exception reached";
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu