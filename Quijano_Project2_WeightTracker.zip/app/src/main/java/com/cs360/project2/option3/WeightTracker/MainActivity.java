package com.cs360.project2.option3.WeightTracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private WeightTrackerDatabase mDb;

    private Button mLoginButton;
    private Button mSignUpButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mDb = WeightTrackerDatabase.getInstance(getApplicationContext());

        // Set click handlers
        mLoginButton = findViewById(R.id.logIn);
        mLoginButton.setOnClickListener(this);
        mSignUpButton = findViewById(R.id.signUpButton);
        mSignUpButton.setOnClickListener(this);
    }

    private void handleLoginAttempt(String username, String password) {
        User user = mDb.userDao().getUserByName(username);
        if (user == null) {
            // The user does not exist, show a message and return
            Toast.makeText(this, String.format("User %s does not exist!", username), Toast.LENGTH_LONG).show();
            return;
        }
        if (!user.tryLogin(password)) {
            // Incorrect password
            Toast.makeText(this, "Invalid password", Toast.LENGTH_LONG).show();
            return;
        }

        startWeightActivity(user.getId());
    }

    private void handleSignUpAttempt(String username, String password) {
        User user = mDb.userDao().getUserByName(username);
        if (user != null) {
            // The user does not exist, show a message and return
            Toast.makeText(this, String.format("User %s already exists!", username), Toast.LENGTH_LONG).show();
            return;
        }

        user = new User();
        user.setUsername(username);
        user.setPassword(password);
        mDb.userDao().insertUser(user);
        startWeightActivity(user.getId());
    }

    @Override
    public void onClick(View v) {
        // Make sure a user name has been typed
        EditText mUserNameEdit = findViewById(R.id.userEdit);
        String username = mUserNameEdit.getText().toString();
        if (username.isEmpty()) {
            Toast.makeText(this, R.string.empty_username_warning, Toast.LENGTH_LONG).show();
            return;
        }

        // Make sure a password has been typed
        EditText mPasswordEdit = findViewById(R.id.passwordEdit);
        String password = mPasswordEdit.getText().toString();
        if (password.isEmpty()) {
            Toast.makeText(this, R.string.empty_password_warning, Toast.LENGTH_LONG).show();
            return;
        }

        // Use SHA-256 to save passwords to the DB
        MessageDigest md = null;
        try {
            md = MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

        assert (md != null);
        String shaPass = new String(md.digest(password.getBytes()));

        // Pass along the username and password
        if (v == mLoginButton) {
            handleLoginAttempt(username, shaPass);
        } else if (v == mSignUpButton) {
            handleSignUpAttempt(username, shaPass);
        }
    }

    private void startWeightActivity(long userId) {
        Intent intent = new Intent(this, WeightActivity.class);
        intent.putExtra(WeightActivity.USER_ID, userId);
        startActivity(intent);
    }
}