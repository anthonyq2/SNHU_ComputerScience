package com.cs360.project2.option3.WeightTracker;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface WeightDao {
    @Insert
    void insertWeight(Weight weight);

    @Query("SELECT * FROM Weight WHERE id = :id")
    Weight getWeightById(long id);

    @Query("SELECT * FROM Weight WHERE userId = :userId")
    List<Weight> getWeightsByUser(long userId);

    @Delete
    void deleteWeight(Weight weight);
}
