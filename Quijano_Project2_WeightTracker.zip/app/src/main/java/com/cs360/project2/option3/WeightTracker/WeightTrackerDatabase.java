package com.cs360.project2.option3.WeightTracker;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.DatabaseConfiguration;
import androidx.room.InvalidationTracker;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteOpenHelper;

@Database(entities = {User.class, Weight.class}, version =  3, exportSchema = false)
public abstract class WeightTrackerDatabase extends RoomDatabase {
    private static final String DATABASE_NAME = "weighttracker.db";
    private static WeightTrackerDatabase mWeightTrackerDatabase;

    // Singleton
    public static WeightTrackerDatabase getInstance(Context context) {
        // Currently performing destructive migrations. Note that this would not be appropriate
        // for production code and is only setup this way for this project.
        if (mWeightTrackerDatabase == null) {
            mWeightTrackerDatabase = Room.databaseBuilder(context, WeightTrackerDatabase.class,
                    DATABASE_NAME).fallbackToDestructiveMigration().allowMainThreadQueries().build();
        }
        return mWeightTrackerDatabase;
    }

    @NonNull
    @Override
    protected SupportSQLiteOpenHelper createOpenHelper(DatabaseConfiguration config) {
        return null;
    }

    @NonNull
    @Override
    protected InvalidationTracker createInvalidationTracker() {
        return null;
    }

    @Override
    public void clearAllTables() {

    }

    public abstract UserDao userDao();
    public abstract WeightDao weightDao();
}
