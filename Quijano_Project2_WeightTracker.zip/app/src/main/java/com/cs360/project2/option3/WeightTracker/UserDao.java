package com.cs360.project2.option3.WeightTracker;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

@Dao
public interface UserDao {
    @Query("SELECT * FROM User WHERE username = :username")
    User getUserByName(String username);

    @Insert()
    void insertUser(User user);
}
