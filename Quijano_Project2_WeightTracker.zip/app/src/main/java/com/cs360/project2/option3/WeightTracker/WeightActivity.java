package com.cs360.project2.option3.WeightTracker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;

import java.util.List;
import java.util.Locale;

public class WeightActivity extends AppCompatActivity {
    // column indexes
    private final short DATE_TEXT_COLUMN = 0;
    private final short WEIGHT_VALUE_COLUMN = 1;
    private final short DELETE_BUTTON_COLUMN = 2;

    private final short DELETE_BUTTON_WIDTH = 40;
    public static final String USER_ID = "com.cs360.project2.option3.userid";
    private WeightTrackerDatabase mDb;
    private long activeUserId;

    private void addDateEdit(Weight weight, TableRow row) {
        TableRow.LayoutParams rowParams = new TableRow.LayoutParams();
        rowParams.width = TableRow.LayoutParams.WRAP_CONTENT;
        rowParams.height = TableRow.LayoutParams.MATCH_PARENT;
        rowParams.column = DATE_TEXT_COLUMN;

        // Add the date text
        EditText dateText  = new EditText(this);
        dateText.setText(weight.getDate());
        dateText.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                TableRow.LayoutParams.WRAP_CONTENT));
        dateText.setInputType(InputType.TYPE_NULL);
        row.addView(dateText, rowParams);
    }

    private void addDeleteButton(Weight weight, TableRow row) {
        // Add the delete button
        TableRow.LayoutParams rowParams = new TableRow.LayoutParams();
        rowParams.width = TableRow.LayoutParams.WRAP_CONTENT;
        rowParams.height = TableRow.LayoutParams.MATCH_PARENT;
        rowParams.column = DELETE_BUTTON_COLUMN;
        Button button = new Button(this);

        // Measure the appropriate size for the device
        float scale = getResources().getDisplayMetrics().density;
        int dpAsPixels = (int) (DELETE_BUTTON_WIDTH * scale + 0.5f);

        button.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dpAsPixels));
        button.setText(R.string.delete);

        // Add a listener for each button to allow for the weight to be deleted
        button.setOnClickListener(v -> {
            mDb.weightDao().deleteWeight(weight);
            refreshWeights();
        });

        // TODO - For some reason setting the color of the button messes with the button size.
        //  Possibly revisit this later.
        // button.setBackgroundColor(getResources().getColor(R.color.main_red));
        // button.setTextColor(getResources().getColor(R.color.white));
        row.addView(button, rowParams);
    }

    private void addValueEdit(Weight weight, TableRow row) {
        TableRow.LayoutParams rowParams = new TableRow.LayoutParams();
        rowParams.width = TableRow.LayoutParams.WRAP_CONTENT;
        rowParams.height = TableRow.LayoutParams.MATCH_PARENT;
        rowParams.column = WEIGHT_VALUE_COLUMN;

        EditText weightText = new EditText(this);
        weightText.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        weightText.setText(String.format(Locale.getDefault(), "%f", weight.getValue()));
        weightText.setInputType(InputType.TYPE_NULL);
        row.addView(weightText, rowParams);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight);

        Intent intent = getIntent();
        activeUserId = intent.getLongExtra(USER_ID, -1);

        mDb = WeightTrackerDatabase.getInstance(getApplicationContext());
        refreshWeights();

        Button mAddWeight = findViewById(R.id.addWeightButton);
        mAddWeight.setOnClickListener(v -> {
            FragmentManager fragmentManager = getSupportFragmentManager();
            NewWeightDialog dialog = new NewWeightDialog();
            fragmentManager.registerFragmentLifecycleCallbacks(new FragmentManager.FragmentLifecycleCallbacks() {
                @Override
                public void onFragmentDestroyed(@NonNull FragmentManager fm, @NonNull Fragment f) {
                    if (f == dialog) {
                        // Ensure the weights are updated when the NewWeightDialog finishes
                        refreshWeights();
                    }
                }
            }, false);

            Bundle args = new Bundle();
            args.putLong("userId", activeUserId);
            dialog.setArguments(args);
            dialog.show(fragmentManager, "newWeightDialog");
        });
    }

    private void refreshWeights() {
        List<Weight> weights = mDb.weightDao().getWeightsByUser(activeUserId);
        TableLayout table = findViewById(R.id.weightsTable);

        for (int i = table.getChildCount() - 1; i >= 1; --i) {
            // remove all except the first, descriptor view
            table.removeViewAt(i);
        }

        // Add the weight objects to the table
        for (int i = 0; i < weights.size(); ++i) {
            Weight weight = weights.get(i);
            TableRow row = new TableRow(this);

            // Add the views to the row
            addDateEdit(weight, row);
            addValueEdit(weight, row);
            addDeleteButton(weight, row);

            // add one to the index due to the descriptor view
            table.addView(row, i + 1);
        }
    }
}
