package com.cs360.project2.option3.WeightTracker;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "User")

public class User {
    @PrimaryKey(autoGenerate =  true)
    @ColumnInfo(name = "id")
    private long mId;

    @ColumnInfo(name = "username")
    private String mUsername = "";

    @ColumnInfo(name = "password")
    private String mPassword = "";

    public long getId() {
        return mId;
    }

    public void setId(final long id) {
        mId = id;
    }

    public String getUsername() {
        return mUsername;
    }

    public void setUsername(final String username) {
        mUsername = username;
    }

    public String getPassword() {
        return mPassword;
    }

    public void setPassword(final String password) {
        mPassword = password;
    }

    public boolean tryLogin(String password) {
        return password.equals(mPassword);
    }
}
