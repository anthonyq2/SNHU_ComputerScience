package com.cs360.project2.option3.WeightTracker;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

public class NewWeightDialog extends DialogFragment {
    WeightTrackerDatabase mDb;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        LayoutInflater inflater = LayoutInflater.from(getContext());
        View view = inflater.inflate(R.layout.dialog_new_weight, null);
        EditText weightDate = view.findViewById(R.id.weightDate);
        EditText weightValue = view.findViewById(R.id.weightValue);

        // Build the dialog
        final AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setView(view);
        builder.setTitle("Enter New Weight:");
        builder.setPositiveButton("Add", (dialog, which) -> {
            // Save the weight to the database before returning
            mDb = WeightTrackerDatabase.getInstance(getContext());
            Weight weight = new Weight();
            weight.setDate(weightDate.getText().toString());
            weight.setValue(Float.parseFloat(weightValue.getText().toString()));
            weight.setUserId(getArguments().getLong("userId"));
            mDb.weightDao().insertWeight(weight);
        });
        builder.setNegativeButton("Back", (dialog, which) -> dialog.cancel());

        return builder.create();
    }
}
